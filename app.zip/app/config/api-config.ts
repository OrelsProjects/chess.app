/* App config for apis
 */
const ApiConfig = {
  BASE_URL: 'http://wolverine-dev.com/',
  LOGIN: 'api/login',
};

export default ApiConfig;
