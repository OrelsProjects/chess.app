import { store } from 'app/redux/store/store';
import axios from 'axios';
import { useState } from 'react';
import { useSelector } from 'react-redux';

// const [header, setHeader] = useState('');

// const headerFound = useSelector(state => state.auth);
// setHeader(headerFound?.user);
//console.log('headerFound>>>> ', headerFound.user);

export const BaseURL = axios.create({
  baseURL: 'https://0j3kvj5lpl.execute-api.us-east-1.amazonaws.com',
  // baseURL: Platform.OS === 'ios' ? iosUrl : androidUrl,
  headers: {
    //accept: 'application/json',
    'content-type': 'text/plain; charset=utf-8',
    // UserId: header,
    UserId: store.getState().auth.user,
  },
});

export const endPoints = {
  signUp: '/users',
  searchUser: '/search/users/saif/1/10',
  signIn: `/users/${store.getState().auth.user}`,
  calculateRating: `/expectedRating/new`,
  getUserApi: `/users/${store.getState().auth.user}`,
  forgotPassword: '/user-management/forgot-password',
  recoverPassword: '/user-management/recover-password',
  reset:'/calculation/reset'
};
